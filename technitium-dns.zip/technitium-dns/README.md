# technitium-dns — Technitium DNS Server with encrypted DoT/DoH behind nginx

Everything is configured in `.env`. Works the same on the Linode and on a home VM.

```
 phone / PC ──TLS (your wildcard cert)──► nginx ──TLS + client cert──► tls-backend ──► Technitium
                                         (any host)   (mutual TLS)      (this stack)
```

- **nginx** handles the public DoT (853) and DoH (443) with the cert it already has.
- The hop from nginx to this stack is **always encrypted and mutually authenticated** with a local CA the stack makes itself. So it doesn't matter whether nginx uses host networking (Linode) or its own Docker network (home): it's the same config. Only a client holding nginx's client cert can use the backend ports.
- **Real client IPs** reach Technitium for DoT (PROXY protocol) and DoH (`X-Real-IP`), so its logs, stats and per-IP rate limits see each device, not nginx.
- **Optional `direct-tls` profile** (home): certbot gets a real cert for your own domain (Cloudflare DNS-01) and devices can use DoT/DoH straight to this box. Off by default.
- **AdGuard-format block/allow lists** pasted at the bottom of `.env`.
- **Resource-capped** (CPU, RAM, no swap, process count) so it can't starve other services.

## Install (first time)

Run from your home folder. This installs through `deploy-update.sh` itself, so the update baseline is recorded from day one:
```
cd ~ && \
curl -fsSL -o /tmp/technitium.zip https://github.com/AngelGonePro/technitium-dns-docker-compose/raw/refs/heads/main/technitium-dns.zip && \
python3 -c "import zipfile; open('/tmp/deploy-update.sh','wb').write(zipfile.ZipFile('/tmp/technitium.zip').read('technitium-dns/deploy-update.sh'))" && \
sh /tmp/deploy-update.sh https://github.com/AngelGonePro/technitium-dns-docker-compose/raw/refs/heads/main/technitium-dns.zip technitium-dns && \
cp /tmp/deploy-update.sh technitium-dns/ && chmod +x technitium-dns/*.sh technitium-dns/helper/helper && rm -f /tmp/technitium.zip /tmp/deploy-update.sh
```
Set at least `DNS_ADMIN_USERNAME` and `DNS_ADMIN_PASSWORD`. The stack refuses to start without them, and refuses `admin` for either:
```
nano ~/technitium-dns/.env
```
Port 53 must be free. If an older Technitium (e.g. from the VPN stack) or `systemd-resolved` holds it, stop that first:
```
sudo ss -tulpn 'sport = :53'
```
Start it:
```
cd ~/technitium-dns && ./update.sh
```
`update.sh` pulls/builds, starts, and waits until Technitium, the TLS backend and the settings sync are all healthy. Web console: `http://<host>:5380`, logging in with your `DNS_ADMIN_USERNAME`. Technitium always creates its first account as `admin`; the settings sync renames it to your username on the first start, so `admin` doesn't exist to be guessed.

## Update from GitHub (keeps .env, your lists, config, certs)

```
cd ~/technitium-dns
./deploy-update.sh https://github.com/AngelGonePro/technitium-dns-docker-compose/raw/refs/heads/main/technitium-dns.zip .
./update.sh
```
`deploy-update.sh` never touches `.env`, `data/`, `certs/`, `backups/` or `update.log`. New `.env` keys are appended at the bottom for review, and your pasted lists are left exactly as they are. Files you hand-edited are left alone and reported.

**New Technitium version:** set `TECHNITIUM_VERSION` in `.env`, then `./update.sh`. It backs up the config folder first (a new version may upgrade its format). If the new version fails its checks, it restores the old version and that backup, then alerts `UPDATE_ALERT_WEBHOOK`. `./update.sh` on its own also picks up Ubuntu security updates for the helper image.

## nginx setup (Linode and home are the same)

1. **Copy the three nginx files** from this stack's `certs/local/` into nginx-ui's conf dir on the nginx host, under `ssl/technitium/`.

   Linode (nginx on the same box):
   ```
   mkdir -p ~/linode-nginx-stack/nginx-conf/ssl/technitium
   cp ~/technitium-dns/certs/local/{ca.crt,nginx-client.crt,nginx-client.key} ~/linode-nginx-stack/nginx-conf/ssl/technitium/
   ```
   Home (DNS stack and nginx both on debian-proxy):
   ```
   mkdir -p ~/proxy-nginx/nginx-conf/ssl/technitium
   cp ~/technitium-dns/certs/local/{ca.crt,nginx-client.crt,nginx-client.key} ~/proxy-nginx/nginx-conf/ssl/technitium/
   ```
   They're valid for 10 years and the stack never replaces them on its own, so this is a one-time copy.

2. **Add the two configs** from `nginx-configs/` in nginx-ui. They're the same files on the Linode and at home:
   - `dot-stream.conf`: DoT on 853.
   - `doh-site.conf`: DoH on 443 (direct, or Cloudflare Tunnel to `https://<host>:443`) and on 80 (Cloudflare Tunnel to `http://<host>:80`).

   Both send to `172.17.0.1`, the host's default Docker bridge (`docker0`). That address reaches the DNS stack whether nginx-ui uses host networking (Linode) or its own Docker network (home). Check it exists on a host with `ip -4 addr show docker0`. If yours differs, change the `server 172.17.0.1:…` line in both files.

   `server_name` in `doh-site.conf` lists `dns.cosmoscraft.net`, `dnscloudhostaccess.cosmoscraft.net` and `dnshome.cosmoscraft.net`. Edit both server blocks if you use other names.

   The stream goes under nginx-ui's **Streams**, and after saving it you must **enable** it. A stream pasted under Sites fails with `"ssl_handshake_timeout" directive is not allowed here`. The site goes under **Sites**. All of them use your existing wildcard cert at `/etc/nginx/ssl/letsencrypt/live/cosmoscraft.net/`.

3. Reload nginx in nginx-ui. Test from any machine:
   ```
   kdig +tls @dns.cosmoscraft.net example.com
   kdig +https=/dns-query @dns.cosmoscraft.net example.com
   ```
   On Android, Private DNS = `dns.cosmoscraft.net`.

The DoT/DoH hostname's DNS record must be **DNS-only (grey cloud)** on Cloudflare, pointing at the Linode (45.79.25.46), since 853 can't pass through Cloudflare's proxy.

## Home setup on debian-proxy, step by step

The DNS stack and nginx-ui-home both run on debian-proxy (`10.0.0.100`).

| Name | Used for | Points at |
|---|---|---|
| `dnshome.cosmoscraft.net` | DoT (853) and DoH (443), LAN/VPN only | `10.0.0.100` |
| `dohome.cosmoscraft.net` | DoH through the Cloudflare Tunnel, from anywhere | the tunnel, which sends it to `http://10.0.0.100:80` |

1. **Check the ports and subnet are free on debian-proxy.** You should get no output from these two:
   ```
   ss -tulpn | grep -E ':(53|5380|5843|5853) '
   docker network inspect $(docker network ls -q) -f '{{.Name}} {{range .IPAM.Config}}{{.Subnet}} {{end}}' | grep 172.29.53
   ```
   If something holds 53 (e.g. `systemd-resolved` or dnsmasq), stop it first. If 172.29.53.0/24 is taken, change `DNS_NET_SUBNET`, `TLS_BACKEND_IP` and `TLS_DIRECT_IP` in `.env`.
2. **Install** with the one-command install at the top of this README.
3. **`nano ~/technitium-dns/.env`:**
   - Set `DNS_ADMIN_USERNAME` and `DNS_ADMIN_PASSWORD`.
   - Set `WEB_BIND=10.0.0.100`, so the console is on the LAN only.
   - Paste your AdGuard rules into `DNS_CUSTOM_RULES`. `DNS_BLOCKLIST_URLS` comes pre-filled.
   - Leave `COMPOSE_PROFILES` empty, since nginx does the TLS.
   - Leave `DNS_MEM_LIMIT=512m`.
4. **Start it:** `cd ~/technitium-dns && ./update.sh`
5. **Copy the nginx client certs** into proxy-nginx (step 1 of "nginx setup" above, Home).
6. **Port 853 on nginx-ui-home:** proxy-nginx's current release already publishes it (`DOT_PORT=853`). If your installed copy predates that, update it the usual way:
   ```
   cd ~/proxy-nginx
   ./deploy-update.sh https://raw.githubusercontent.com/AngelGonePro/docker-compose-proxy/refs/heads/main/proxy-nginx.zip .
   docker compose up -d --remove-orphans
   ```
   Then `docker port nginx-ui-home | grep 853` should show it.
7. **In nginx-ui** (`http://10.0.0.100:9001`):
   - Manage Streams → add `nginx-configs/dot-stream.conf` → **Enable** it.
   - Manage Sites → add `nginx-configs/doh-site.conf`.
8. **Check nginx loaded it** on debian-proxy. You should see `test is successful`, a `listen 853` line, and something listening on 853:
   ```
   docker exec nginx-ui-home nginx -t
   docker exec nginx-ui-home nginx -T 2>/dev/null | grep -n "listen 853"
   ss -tlnp 'sport = :853'
   ```
9. **DNS record for the LAN name.** On Cloudflare, add `dnshome` as an A record → `10.0.0.100`, **DNS-only** (grey cloud). A private IP in public DNS is fine: it only works for devices on your LAN/VPN. Alternatively, add it as a zone in this Technitium (Zones → Add Zone `dnshome.cosmoscraft.net`, Primary → record `@` A `10.0.0.100`), if your network hands out this server as its DNS.
10. **Cloudflare Tunnel:** Zero Trust → Networks → Tunnels → your tunnel → Public Hostname → add `dohome.cosmoscraft.net`, Service **HTTP**, URL `10.0.0.100:80`. The real visitor IP arrives in `CF-Connecting-IP`, and nginx passes it to Technitium.
    - nginx trusts that header only from `172.30.0.1`, the same as proxy-nginx's `CLOUDFLARED_SOURCE_IPS`, which is how cloudflared appears when it runs in its own Docker compose project.
    - If you change `CLOUDFLARED_SOURCE_IPS` (e.g. cloudflared on `network_mode: host` → `10.0.0.100`), change the `set_real_ip_from` lines in both server blocks of `doh-site.conf` to match.
11. **In the Technitium console** (`http://10.0.0.100:5380`):
    - **Settings → Recursion:** set it to **Allow** if you want `dohome` to work from outside your network. Tunnel visitors arrive with their real public IP. Your home port 53 isn't port-forwarded, so this is safe.
    - **Settings → Proxy & Forwarders:** DoH forwarders, if you want them.
    - **Settings → Blocking → Blocking Type:** Any Address, if you want `0.0.0.0` answers.
12. **Test.** From a LAN device (Termux on home Wi-Fi):
    ```
    dig +tls +tls-ca +tls-hostname=dnshome.cosmoscraft.net @dnshome.cosmoscraft.net example.com
    dig +https +tls-ca +tls-hostname=dnshome.cosmoscraft.net @dnshome.cosmoscraft.net example.com
    ```
    From anywhere, through the tunnel:
    ```
    curl -s -o /dev/null -w '%{http_code}\n' --doh-url https://dohome.cosmoscraft.net/dns-query https://example.com
    ```
    To confirm real IPs, turn on Settings → Logging → Log All Queries, query, then look at the client IPs in the console's Logs. Turn it off again afterwards if you don't want the extra logging.

**If the console or DNS times out from a LAN device:** debian-proxy is also your WireGuard gateway with policy routing. If its rules send this stack's replies out the tunnel (that's what happened on the Linode), run `tcpdump -ni any tcp port 5380` while you retry and look for packets leaving through the wrong interface.

## Direct TLS at home (optional)

For devices that should use DoT/DoH straight to the DNS VM with its own real cert:
```
COMPOSE_PROFILES=direct-tls
CERTBOT_DOMAIN=dns.home.example.com
CERTBOT_EMAIL=you@example.com
CF_API_TOKEN=...            # Cloudflare token, Zone:DNS:Edit
```
Then `./update.sh`. certbot uses DNS-01, so no inbound ports are needed and the name can point at a LAN IP. DoT is served on `DIRECT_DOT_PORT` (853) and DoH on `DIRECT_DOH_PORT` (443). Renewals are picked up automatically within a minute, with no restart. This profile also works alongside the nginx setup.

## Block lists (AdGuard format)

`DNS_BLOCKLIST_URLS` at the bottom of `.env` comes pre-filled with 41 lists (the AdGuard Home set). To change them, paste between the two `"` lines, then run `docker compose up -d`.
- Paste one URL per line, or copy AdGuard Home's "DNS blocklists" page as-is. Only the URLs are used; names, rule counts and dates are ignored.
- Remove a URL to remove that list. Lists you add in the web console yourself are kept.
- Technitium downloads them and re-downloads every 24 h (Settings → Blocking to change that).
- This block uses double quotes because list names have apostrophes, so don't paste a `"` into it.
- Memory, measured with all 41 lists (1.78 M entries): ~290–340 MiB. That's why `DNS_MEM_LIMIT` defaults to `512m`.

**Your custom rules always win over the lists:**
- Your `@@` allows beat anything a list blocks.
- Your `||` blocks beat anything a list allows. Lists contain their own `@@` rules; for example, HaGeZi's Allowlist Referral allows `ad.doubleclick.net`. Technitium alone would let those win, so the stack gives each such name a local zone and your block wins.
- That stays true after the lists update. The `list-watch` service notices every re-download (checked every `LIST_WATCH_SECONDS`, default 60 s) and adds or removes those zones. `docker logs technitium-list-watch` shows what it did.

## Custom rules (AdGuard format)

Paste your whole AdGuard list, exactly as AdGuard gives it, between the two quote lines at the bottom of `.env`. Blocks and allows go in together; there's nothing to separate. Then run `docker compose up -d`.
```
DNS_CUSTOM_RULES='
@@||nextdns.io^
@@||nvidia.com^
||telemetry.gfe.nvidia.com
||tiktok.com^
'
```
- `||x^` blocks a domain and its subdomains. `@@||x^` allows it, overriding any block list, including ones you add in the web console.
- Hosts lines (`0.0.0.0 x`) and plain domains block. `!` and `#` lines are comments. Typos like `^^` and duplicates are fine.
- **A block rule under an allowed domain still blocks.** For example, `||telemetry.gfe.nvidia.com` is blocked while `@@||nvidia.com^` keeps the rest of nvidia.com working.
  - Technitium itself always lets an allow win, so for each such rule the stack creates an empty local zone with that name. The name and its subdomains then get no address.
  - These zones show in the web console under Zones and are listed in `docker logs technitium-configure`.
  - Remove the rule from `.env` and the zone is removed. Delete one in the web console and it comes back on the next `docker compose up -d`.
  - Zones you made yourself are never touched.
  - Unlike list blocks, these aren't paused by the web console's "Temporarily Disable Blocking".
- Technitium can't do regex rules, wildcards in the middle of a name, or `$client`/`$dnsrewrite`-style modifiers. Those lines are skipped and listed in `docker logs technitium-configure`.
- The rules are read straight from the `.env` file, so big pastes are fine (tested with 300,000 rules).
- Remove a line and re-run `docker compose up -d` to undo it. The rules show in Technitium as two `file:///etc/dns/lists/...` block list entries. Any other block list URLs you add in the web console are kept.

## What the stack manages vs. what's yours

The settings sync (`configure`) only owns:
- Technitium's internal DNS-over-TCP-PROXY (538) and DNS-over-HTTP (80) listeners. They're never published; only the TLS fronts use them.
- The reverse-proxy ACL: real client IPs are trusted only from the TLS fronts' fixed IPs.
- The two custom-list entries.

Everything else (recursion, forwarders, blocking type, block list URLs, zones, apps) is yours in the web console. The `DNS_SERVER_*` values in `.env` only seed the very first start.

The sync logs in with `DNS_ADMIN_USERNAME` / `DNS_ADMIN_PASSWORD`. To change the username, change it in `.env` and run `docker compose up -d`, and the account is renamed. If you change the password in the web console, change `DNS_ADMIN_PASSWORD` in `.env` to match.

## Checks

```sh
docker compose ps                                   # all healthy, init/configure exited 0
docker logs technitium-configure                    # list counts, skipped rules, settings changes
docker logs technitium-list-watch                   # custom blocks enforced over list allows
docker stats --no-stream                            # usage vs. limits
dig @127.0.0.1 example.com                          # plain DNS on this host
```
To see real client IPs per query: web console → Settings → Logging → Log All Queries.

## Notes

- **Resource limits:** `DNS_MEM_LIMIT` (512m; ~45 MiB with no block lists, ~290–340 MiB with the 41 defaults), `DNS_CPUS` (0.50), `DNS_PIDS_LIMIT` (512, since .NET threads count), no swap. The TLS fronts get 64m / 0.25 CPU. Measured in testing:

  | State | Technitium | TLS backend |
  |---|---|---|
  | Idle | ~46 MiB, ~0% CPU | ~16 MiB |
  | 300k-rule custom list loaded | ~160 MiB | |
  | ~3,000 queries/s over DoT through nginx | held at its 0.50 CPU cap, 0 lost | ~17 MiB, ~10% CPU |
- **Rate limits:** Technitium's default is 600 queries/min per client IP. That's another reason the real IP matters: without it, every DoT/DoH device would share nginx's IP and one limit.
- **Recursion:** the first-start default is `AllowOnlyForPrivateNetworks`. DoT/DoH clients arrive with their real IP, so phones on mobile data are public IPs. If you want DoT/DoH to work for them, set Recursion to Allow in the web console, and keep plain port 53 firewalled from the internet.
- **Ports:** 53/udp+tcp, 5380 (console), 5853 (DoT backend), 5843 (DoH backend), and 853/443 only with `direct-tls`. All are configurable in `.env`.
- **Internal network:** `DNS_NET_SUBNET` (172.29.53.0/24) is fixed so the trusted TLS-front IPs are exact. Change it if that range is taken on the host.
