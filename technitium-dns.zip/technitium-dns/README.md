# technitium-dns — Technitium DNS Server with encrypted DoT/DoH behind nginx

Everything is configured in `.env`. Works the same on the Linode and on a home VM.

```
 phone / PC ──TLS (your wildcard cert)──► nginx ──TLS + client cert──► tls-backend ──► Technitium
                                         (any host)   (mutual TLS)      (this stack)
```

- **nginx** handles the public DoT (853) and DoH (443) with the cert it already has.
- The hop from nginx to this stack is **always encrypted and mutually authenticated** with a local CA the stack makes itself. So it doesn't matter whether nginx is on the same box (Linode, `127.0.0.1`) or another VM (home, `10.0.0.53`): it's the same config. Only a client holding nginx's client cert can use the backend ports.
- **Real client IPs** reach Technitium for DoT (PROXY protocol) and DoH (`X-Real-IP`), so its logs, stats and per-IP rate limits see each device, not nginx.
- **Optional `direct-tls` profile** (home): certbot gets a real cert for your own domain (Cloudflare DNS-01) and devices can use DoT/DoH straight to this box. Off by default.
- **AdGuard-format block/allow lists** pasted at the bottom of `.env`.
- **Resource-capped** (CPU, RAM, no swap, process count) so it can't starve other services.

## Install (first time)

Run from your home folder. This installs through `deploy-update.sh` itself, so the update baseline is recorded from day one:
```
cd ~ && \
curl -fsSL -o /tmp/technitium.zip https://github.com/AngelGonePro/technitium-dns-docker-compose/raw/refs/heads/main/technitium-dns.zip && \
python3 -c "import zipfile; open('/tmp/deploy-update.sh','wb').write(zipfile.ZipFile('/tmp/technitium.zip').read('technitium-dns/deploy-update.sh'))" && \
sh /tmp/deploy-update.sh https://github.com/AngelGonePro/technitium-dns-docker-compose/raw/refs/heads/main/technitium-dns.zip technitium-dns && \
cp /tmp/deploy-update.sh technitium-dns/ && chmod +x technitium-dns/*.sh technitium-dns/helper/helper && rm -f /tmp/technitium.zip /tmp/deploy-update.sh
```
Set at least `DNS_ADMIN_PASSWORD` (the stack refuses to start without it):
```
nano ~/technitium-dns/.env
```
Port 53 must be free. If an older Technitium (e.g. from the VPN stack) or `systemd-resolved` holds it, stop that first:
```
sudo ss -tulpn 'sport = :53'
```
Start it:
```
cd ~/technitium-dns && ./update.sh
```
`update.sh` pulls/builds, starts, and waits until Technitium, the TLS backend and the settings sync are all healthy. Web console: `http://<host>:5380`, user `admin`.

## Update from GitHub (keeps .env, your lists, config, certs)

```
cd ~/technitium-dns
./deploy-update.sh https://github.com/AngelGonePro/technitium-dns-docker-compose/raw/refs/heads/main/technitium-dns.zip .
./update.sh
```
`deploy-update.sh` never touches `.env`, `data/`, `certs/`, `backups/` or `update.log`. New `.env` keys are appended at the bottom for review, and your pasted lists are left exactly as they are. Files you hand-edited are left alone and reported.

**New Technitium version:** set `TECHNITIUM_VERSION` in `.env`, then `./update.sh`. It backs up the config folder first (a new version may upgrade its format). If the new version fails its checks, it restores the old version and that backup, then alerts `UPDATE_ALERT_WEBHOOK`. `./update.sh` on its own also picks up Ubuntu security updates for the helper image.

## nginx setup (Linode and home are the same)

1. **Copy the three nginx files** from this stack's `certs/local/` into nginx-ui's conf dir on the nginx host, under `ssl/technitium/`.

   Linode (nginx on the same box):
   ```
   mkdir -p ~/linode-nginx-stack/nginx-conf/ssl/technitium
   cp ~/technitium-dns/certs/local/{ca.crt,nginx-client.crt,nginx-client.key} ~/linode-nginx-stack/nginx-conf/ssl/technitium/
   ```
   Home (DNS on debian-dns, nginx on debian-proxy), run on debian-dns (adjust `proxy-nginx/` if it lives elsewhere on debian-proxy):
   ```
   ssh root@10.0.0.100 mkdir -p proxy-nginx/nginx-conf/ssl/technitium
   scp ~/technitium-dns/certs/local/{ca.crt,nginx-client.crt,nginx-client.key} root@10.0.0.100:proxy-nginx/nginx-conf/ssl/technitium/
   ```
   They're valid for 10 years and the stack never replaces them on its own, so this is a one-time copy.

2. **Add the two configs for that host** from `nginx-configs/` in nginx-ui. They're ready to use as-is:

   | Host | Stream (DoT, 853) | Site (DoH, 443) | Backend |
   |---|---|---|---|
   | Linode | `nginx-configs/linode/dot-stream.conf` | `nginx-configs/linode/doh-site.conf` | `127.0.0.1` |
   | Home (debian-proxy) | `nginx-configs/home/dot-stream.conf` | `nginx-configs/home/doh-site.conf` | debian-dns `10.0.0.53` |

   The stream goes under nginx-ui's Streams, and the site under Sites. Both use your existing wildcard cert at `/etc/nginx/ssl/letsencrypt/live/cosmoscraft.net/` and the hostname `dns.cosmoscraft.net`.

3. Reload nginx in nginx-ui. Test from any machine:
   ```
   kdig +tls @dns.cosmoscraft.net example.com
   kdig +https=/dns-query @dns.cosmoscraft.net example.com
   ```
   On Android, Private DNS = `dns.cosmoscraft.net`.

The DoT/DoH hostname's DNS record must be **DNS-only (grey cloud)** on Cloudflare, pointing at the Linode (45.79.25.46), since 853 can't pass through Cloudflare's proxy.

### Same name at home and away

Both config sets use `dns.cosmoscraft.net`, so a phone's Private DNS setting never has to change. To make devices on your home network use the home nginx instead of going out to the Linode, have your home Technitium answer that one name locally. In the home Technitium web console:

- **Zones → Add Zone:** `dns.cosmoscraft.net`, type Primary.
- **Add Record:** `@` A `10.0.0.100` (debian-proxy).

At home, devices now resolve it to debian-proxy. Everywhere else, public DNS sends them to the Linode.

## Direct TLS at home (optional)

For devices that should use DoT/DoH straight to the DNS VM with its own real cert:
```
COMPOSE_PROFILES=direct-tls
CERTBOT_DOMAIN=dns.home.example.com
CERTBOT_EMAIL=you@example.com
CF_API_TOKEN=...            # Cloudflare token, Zone:DNS:Edit
```
Then `./update.sh`. certbot uses DNS-01, so no inbound ports are needed and the name can point at a LAN IP. DoT is served on `DIRECT_DOT_PORT` (853) and DoH on `DIRECT_DOH_PORT` (443). Renewals are picked up automatically within a minute, with no restart. This profile also works alongside the nginx setup.

## Custom block / allow lists (AdGuard format)

Paste rules between the quotes at the bottom of `.env`, then `docker compose up -d`:
```
DNS_CUSTOM_BLOCKLIST='
||ads.example.com^
@@||cdn.example.com^
0.0.0.0 tracker.example.org
'

DNS_CUSTOM_ALLOWLIST='
@@||bank.example.com^
'
```
- Blocklist: `||x^` blocks a domain and its subdomains, `@@||x^` exempts one, hosts lines and plain domains work too, `!` and `#` are comments.
- Your whole AdGuard "Custom filtering rules" list (mixed `@@` and `||` lines) can be pasted as-is into either box. `@@` lines allow and `||` lines still block. Typos like `^^` are fine.
- Allowlist: a plain allowlist (no `@@` lines) means every line is allowed. Allowed entries override any block list, including ones you add in the web console.
- A block rule under an allowed domain still blocks. For example, `||telemetry.gfe.nvidia.com` still blocks while `@@||nvidia.com^` keeps the rest of nvidia.com working.
  - Technitium itself always lets an allow win, so for each such rule the stack creates an empty local zone with that name. The name and its subdomains then get no address.
  - These zones show in the web console under Zones and are listed in `docker logs technitium-configure`.
  - Remove the rule from `.env` and the zone is removed. Delete one in the web console and it comes back on the next `docker compose up -d`.
  - Zones you made yourself are never touched.
  - Unlike list blocks, these aren't paused by the web console's "Temporarily Disable Blocking".
- Technitium can't do regex rules, wildcards in the middle of a name, or `$client`/`$dnsrewrite`-style modifiers. Those lines are skipped and listed in `docker logs technitium-configure`.
- The lists are read straight from the `.env` file, so big pastes are fine (tested with 300,000 rules).
- Remove a line and re-run `docker compose up -d` to un-block it. The lists from `.env` show in Technitium as two `file:///etc/dns/lists/...` block list entries. Any other block list URLs you add in the web console are kept.

## What the stack manages vs. what's yours

The settings sync (`configure`) only owns:
- Technitium's internal DNS-over-TCP-PROXY (538) and DNS-over-HTTP (80) listeners. They're never published; only the TLS fronts use them.
- The reverse-proxy ACL: real client IPs are trusted only from the TLS fronts' fixed IPs.
- The two custom-list entries.

Everything else (recursion, forwarders, blocking type, block list URLs, zones, apps) is yours in the web console. The `DNS_SERVER_*` values in `.env` only seed the very first start.

If you change the admin password in the web console, change `DNS_ADMIN_PASSWORD` in `.env` too. The sync logs in as admin.

## Checks

```sh
docker compose ps                                   # all healthy, init/configure exited 0
docker logs technitium-configure                    # list counts, skipped rules, settings changes
docker stats --no-stream                            # usage vs. limits
dig @127.0.0.1 example.com                          # plain DNS on this host
```
To see real client IPs per query: web console → Settings → Logging → Log All Queries.

## Notes

- **Resource limits:** `DNS_MEM_LIMIT` (384m), `DNS_CPUS` (0.50), `DNS_PIDS_LIMIT` (512, since .NET threads count), no swap. The TLS fronts get 64m / 0.25 CPU. Measured in testing:

  | State | Technitium | TLS backend |
  |---|---|---|
  | Idle | ~46 MiB, ~0% CPU | ~16 MiB |
  | 300k-rule custom list loaded | ~160 MiB | |
  | ~3,000 queries/s over DoT through nginx | held at its 0.50 CPU cap, 0 lost | ~17 MiB, ~10% CPU |
- **Rate limits:** Technitium's default is 600 queries/min per client IP. That's another reason the real IP matters: without it, every DoT/DoH device would share nginx's IP and one limit.
- **Recursion:** the first-start default is `AllowOnlyForPrivateNetworks`. DoT/DoH clients arrive with their real IP, so phones on mobile data are public IPs. If you want DoT/DoH to work for them, set Recursion to Allow in the web console, and keep plain port 53 firewalled from the internet.
- **Ports:** 53/udp+tcp, 5380 (console), 5853 (DoT backend), 5843 (DoH backend), and 853/443 only with `direct-tls`. All are configurable in `.env`.
- **Internal network:** `DNS_NET_SUBNET` (172.29.53.0/24) is fixed so the trusted TLS-front IPs are exact. Change it if that range is taken on the host.
