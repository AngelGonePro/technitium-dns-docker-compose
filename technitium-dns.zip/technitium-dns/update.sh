#!/usr/bin/env bash
# Starts or updates the stack at the versions pinned in .env, verifies it, and
# rolls back + alerts if the new version doesn't come up healthy.
#
#   ./update.sh     first start, or update after deploy-update.sh / a version bump
#
# To move to a new Technitium release: set TECHNITIUM_VERSION in .env, run this.
# Before switching versions, Technitium's config folder is backed up to backups/,
# because a newer version may upgrade the config format. If the new version fails
# its checks, the old version AND that backup are restored.
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"

LOG=./update.log
STATE=./.update-state   # last version that passed verification
log() { printf '%s %s\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" "$*" | tee -a "$LOG"; }

envval() { sed -n "s/^$1=//p" .env | tail -n1; }
VERSION=$(envval TECHNITIUM_VERSION)
HELPER=$(envval HELPER_IMAGE); HELPER=${HELPER:-local/technitium-dns-helper}
DATA=$(envval DNS_DATA_DIR); DATA=${DATA:-./data}
TIMEOUT=$(envval UPDATE_HEALTH_TIMEOUT); TIMEOUT=${TIMEOUT:-180}
WEBHOOK=$(envval UPDATE_ALERT_WEBHOOK)
PROFILES=$(envval COMPOSE_PROFILES)
[ -n "$VERSION" ] || { log "TECHNITIUM_VERSION is empty in .env"; exit 1; }

alert() {
  log "ALERT: $1"
  [ -n "$WEBHOOK" ] || return 0
  if [[ "$WEBHOOK" == *discord.com/api/webhooks* ]]; then
    curl -fsS -m 15 -H 'Content-Type: application/json' \
      -d "{\"content\": \"⚠️ technitium-dns ($(hostname)): ${1//\"/\\\"}\"}" "$WEBHOOK" >/dev/null || log "webhook send failed"
  else
    curl -fsS -m 15 -d "technitium-dns ($(hostname)): $1" "$WEBHOOK" >/dev/null || log "webhook send failed"
  fi
}

health() { docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' "$1" 2>/dev/null || echo missing; }

verify() {
  local deadline=$((SECONDS + TIMEOUT)) why=""
  local fronts=(technitium-tls-backend technitium-list-watch)
  [[ ",$PROFILES," == *",direct-tls,"* ]] && fronts+=(technitium-tls-direct)
  while (( SECONDS < deadline )); do
    why=""
    [ "$(health technitium-dns)" = healthy ] || why="technitium-dns is $(health technitium-dns)"
    for c in "${fronts[@]}"; do
      [ -z "$why" ] && [ "$(health "$c")" != healthy ] && why="$c is $(health "$c")"
    done
    if [ -z "$why" ]; then
      local st ec
      st=$(docker inspect -f '{{.State.Status}}' technitium-configure 2>/dev/null || echo missing)
      ec=$(docker inspect -f '{{.State.ExitCode}}' technitium-configure 2>/dev/null || echo 1)
      if [ "$st" = exited ] && [ "$ec" = 0 ]; then
        log "verify: all healthy, settings sync OK, $(docker exec technitium-dns dig +short +time=2 +tries=1 @127.0.0.1 localhost A | head -1) for localhost"
        return 0
      fi
      if [ "$st" = exited ]; then why="settings sync failed (exit $ec)"; break; fi
      why="settings sync still running"
    fi
    sleep 5
  done
  log "verify failed after ${TIMEOUT}s: $why"
  for c in technitium-configure technitium-dns technitium-tls-backend; do
    docker logs --tail 15 "$c" 2>&1 | sed "s/^/  $c: /" | tee -a "$LOG" || true
  done
  return 1
}

backup_config() {
  mkdir -p backups
  local f="backups/config-$1-$(date -u +%Y%m%dT%H%M%SZ).tar.gz"
  tar -C "$DATA" -czf "$f" config
  ls -1t backups/config-*.tar.gz 2>/dev/null | tail -n +4 | xargs -r rm -f   # keep the last 3
  echo "$f"
}

log "=== update start: Technitium $VERSION ==="
mkdir -p "$DATA/config"
running=$(docker inspect -f '{{.Config.Image}}' technitium-dns 2>/dev/null | sed 's/.*://' || true)

# Keep the current helper image so a broken rebuild can be undone.
if docker image inspect "$HELPER:latest" >/dev/null 2>&1; then
  docker tag "$HELPER:latest" "$HELPER:rollback"
fi

# Pull and build first, while the current version keeps serving.
if ! docker compose pull dns 2>&1 | tee -a "$LOG"; then
  alert "could not pull technitium/dns-server:$VERSION; nothing changed"
  exit 1
fi
if ! docker compose build --pull 2>&1 | tee -a "$LOG"; then
  alert "helper image build failed; nothing changed"
  exit 1
fi

# Check .env (username, password) and the local certs before touching anything.
if ! out=$(docker compose run --rm --no-deps init 2>&1); then
  printf '%s\n' "$out" | tee -a "$LOG"
  log "fix .env as shown above, then run ./update.sh again (nothing was changed)"
  exit 1
fi

backup=""
if [ -n "$running" ] && [ "$running" != "$VERSION" ] && [ -d "$DATA/config" ]; then
  log "switching Technitium $running -> $VERSION; stopping it briefly to back up its config"
  docker compose stop dns 2>&1 | tee -a "$LOG" || true
  backup=$(backup_config "$running")
  log "config backed up to $backup"
fi

docker compose up -d --remove-orphans 2>&1 | tee -a "$LOG" || true   # verify() decides

if verify; then
  echo "$VERSION" > "$STATE"
  docker image prune -f >/dev/null
  log "=== update OK: Technitium $VERSION ==="
  exit 0
fi

# ── rollback ──
if [ -n "$backup" ] && [ -n "$running" ]; then
  log "rolling back to Technitium $running and restoring its config backup"
  docker compose stop dns 2>&1 | tee -a "$LOG" || true
  mv "$DATA/config" "$DATA/config.failed-$VERSION-$(date -u +%Y%m%dT%H%M%SZ)"
  mkdir -p "$DATA" && tar -C "$DATA" -xzf "$backup"
  sed -i "s/^TECHNITIUM_VERSION=.*/TECHNITIUM_VERSION=$running/" .env
fi
if docker image inspect "$HELPER:rollback" >/dev/null 2>&1; then
  docker tag "$HELPER:rollback" "$HELPER:latest"
fi
docker compose up -d --no-build --remove-orphans 2>&1 | tee -a "$LOG" || true
if verify; then
  alert "update to Technitium $VERSION failed verification — rolled back${running:+ to $running}, which is serving again. Check $LOG."
else
  alert "update to Technitium $VERSION failed AND the rollback failed — DNS may be down. Check $LOG."
fi
exit 1
