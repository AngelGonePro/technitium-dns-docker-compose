#!/usr/bin/env python3
"""Sync the few Technitium settings this stack owns, plus the custom lists from .env.

Only these are touched (everything else stays however you set it in the web console):
  - DNS-over-TCP-PROXY on 538 and DNS-over-HTTP on 80, inside the Docker network only
    (the TLS fronts forward to them; they are never published on the host)
  - the reverse-proxy ACL: real client IPs are trusted only from the TLS fronts' fixed IPs
  - two managed block list entries pointing at the files generated from .env
  - the admin account's username (DNS_ADMIN_USERNAME)
Other block list URLs you add in the web console are kept.
"""
import json
import os
import sys
import time
import urllib.parse
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import envfile  # noqa: E402
import lists  # noqa: E402

API = "http://dns:5380"
STACK_ENV = "/stack.env"
LIST_DIR = "/etc/dns/lists"
BLOCK_URL = "file:///etc/dns/lists/custom-blocklist.txt"
ALLOW_URL = "!file:///etc/dns/lists/custom-allowlist.txt"
OVERRIDE_STATE = "/etc/dns/lists/override-zones.json"
ADMIN_STATE = "/etc/dns/lists/admin-username"


def log(msg):
    print(time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()) + " [configure] " + msg, flush=True)


def call(path, token=None, method="GET", **params):
    if token:
        params["token"] = token
    data = None
    url = API + path
    if method == "POST":
        data = urllib.parse.urlencode(params).encode()
    elif params:
        url += "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, data=data, method=method)
    with urllib.request.urlopen(req, timeout=30) as r:
        body = json.load(r)
    if body.get("status") != "ok":
        raise RuntimeError(f"{path}: {body.get('status')}: {body.get('errorMessage', '')}")
    return body.get("response", {})


def wait_for_api(seconds=180):
    deadline = time.time() + seconds
    while True:
        try:
            with urllib.request.urlopen(API + "/", timeout=5):
                return
        except Exception as e:  # noqa: BLE001
            if time.time() > deadline:
                raise SystemExit(f"Technitium web API not reachable at {API}: {e}")
            time.sleep(2)


def write_if_changed(path, text):
    try:
        with open(path, encoding="utf-8") as f:
            if f.read() == text:
                return False
    except FileNotFoundError:
        pass
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
    os.replace(tmp, path)
    return True


def sync_override_zones(token, overrides):
    """Make block rules under an allowed parent actually block.

    Technitium lets any allow beat any block, so ||telemetry.gfe.nvidia.com would
    lose to @@||nvidia.com^. A local zone is answered before allow/block is even
    checked, so each such name gets an empty Primary zone: the name and all its
    subdomains get no address, while the rest of nvidia.com stays allowed.
    Only zones this stack created (tracked in OVERRIDE_STATE) are ever removed.
    """
    try:
        with open(OVERRIDE_STATE, encoding="utf-8") as f:
            managed = set(json.load(f))
    except (FileNotFoundError, ValueError):
        managed = set()
    existing = {z["name"].lower() for z in call("/api/zones/list", token).get("zones", [])}
    want = set(overrides)

    for zone in sorted(want):
        if zone in existing:
            if zone not in managed:
                log(f"  {zone}: you already have a zone with this name in the web console, leaving it as is")
            continue
        # new, or ours but deleted in the web console: (re)create it
        call("/api/zones/create", token, method="POST", zone=zone, type="Primary")
        managed.add(zone)
        log(f"  blocking {zone} (and its subdomains) even though {overrides[zone]} is allowed")
    for zone in sorted(managed - want):
        if zone in existing:
            call("/api/zones/delete", token, method="POST", zone=zone)
            log(f"  {zone}: block rule removed or no longer under an allowed domain, zone removed")
        managed.discard(zone)
    managed &= want

    write_if_changed(OVERRIDE_STATE, json.dumps(sorted(managed), indent=1) + "\n")
    if want:
        log(f"block-under-allow overrides: {len(want)} active ({', '.join(sorted(want))})")


def login(user, password):
    """Return a session token, or None if these credentials are wrong."""
    req = urllib.request.Request(
        API + "/api/user/login", method="POST",
        data=urllib.parse.urlencode({"user": user, "pass": password, "includeInfo": "false"}).encode())
    with urllib.request.urlopen(req, timeout=30) as r:
        body = json.load(r)
    return body["token"] if body.get("status") == "ok" else None


def admin_session(username, password):
    """Log in as DNS_ADMIN_USERNAME, renaming the account to it first if needed.

    Technitium always creates the first account as "admin" (it has no setting for
    the name), so on the first run it's renamed to DNS_ADMIN_USERNAME. If you
    change DNS_ADMIN_USERNAME later, the account is renamed again, found by the
    name this stack last gave it (ADMIN_STATE).
    """
    try:
        with open(ADMIN_STATE, encoding="utf-8") as f:
            previous = f.read().strip()
    except FileNotFoundError:
        previous = ""
    tried = []
    for name in dict.fromkeys([username, previous, "admin"]):
        if not name:
            continue
        tried.append(name)
        token = login(name, password)
        if token is None:
            continue
        if name.lower() != username.lower():
            call("/api/admin/users/set", token, method="POST", user=name, newUser=username)
            try:
                call("/api/user/logout", token)
            except Exception:  # noqa: BLE001
                pass
            log(f"admin account renamed from '{name}' to '{username}'")
            token = login(username, password)
            if token is None:
                raise SystemExit(f"Renamed the admin account to '{username}' but couldn't log in with it")
        os.makedirs(os.path.dirname(ADMIN_STATE), exist_ok=True)
        write_if_changed(ADMIN_STATE, username + "\n")
        return token
    raise SystemExit(
        f"Login to Technitium failed as {' / '.join(repr(t) for t in tried)}. If you changed the admin "
        "username or password in the web console, put the same ones in DNS_ADMIN_USERNAME and "
        "DNS_ADMIN_PASSWORD in .env, then: docker compose up -d")


def main():
    username = os.environ.get("DNS_ADMIN_USERNAME", "").strip()
    password = os.environ.get("DNS_ADMIN_PASSWORD", "")
    proxies = [ip for ip in (os.environ.get("TLS_BACKEND_IP", ""), os.environ.get("TLS_DIRECT_IP", "")) if ip]

    if not username or username.lower() == "admin" or not password:
        raise SystemExit("DNS_ADMIN_USERNAME and DNS_ADMIN_PASSWORD must both be set in .env "
                         "(and the username can't be 'admin'), then: docker compose up -d")

    wait_for_api()
    token = admin_session(username, password)

    try:
        # ── custom lists ──
        # Read straight from .env (not environment variables), so big pastes work.
        env = envfile.read(STACK_ENV)
        # One paste area with AdGuard rule meaning (|| blocks, @@ allows). The older
        # separate DNS_CUSTOM_BLOCKLIST / DNS_CUSTOM_ALLOWLIST keys still work if present.
        rules = "\n".join(env.get(k, "") for k in ("DNS_CUSTOM_RULES", "DNS_CUSTOM_BLOCKLIST"))
        bl_text, al_text, rep = lists.build(rules, env.get("DNS_CUSTOM_ALLOWLIST", ""))
        os.makedirs(LIST_DIR, exist_ok=True)
        lists_changed = write_if_changed(os.path.join(LIST_DIR, "custom-blocklist.txt"), bl_text)
        lists_changed |= write_if_changed(os.path.join(LIST_DIR, "custom-allowlist.txt"), al_text)
        log(f"custom rules: {rep['blocked']} blocked, {rep['exceptions'] + rep['allowed']} allowed"
            f"{' (changed)' if lists_changed else ' (unchanged)'}")
        for s in rep["skipped"][:50]:
            log("  skipped " + s)
        if len(rep["skipped"]) > 50:
            log(f"  ...and {len(rep['skipped']) - 50} more skipped")

        # ── settings this stack owns ──
        cur = call("/api/settings/get", token)
        want = {
            "enableDnsOverTcpProxy": True, "dnsOverTcpProxyPort": 538,
            "enableDnsOverHttp": True, "dnsOverHttpPort": 80,
            "dnsOverHttpRealIpHeader": "X-Real-IP",
        }
        changes = {k: v for k, v in want.items() if cur.get(k) != v}

        acl = sorted(proxies)
        if sorted(cur.get("dnsReverseProxyNetworkACL") or []) != acl:
            changes["dnsReverseProxyNetworkACL"] = ",".join(acl)

        urls = [u for u in (cur.get("blockListUrls") or []) if u not in (BLOCK_URL, ALLOW_URL)]
        urls += [BLOCK_URL, ALLOW_URL]
        if (cur.get("blockListUrls") or []) != urls:
            changes["blockListUrls"] = ",".join(urls)

        if changes:
            post = {k: (str(v).lower() if isinstance(v, bool) else str(v)) for k, v in changes.items()}
            call("/api/settings/set", token, method="POST", **post)
            log("updated settings: " + ", ".join(sorted(changes)))
        else:
            log("settings already correct")

        if lists_changed or "blockListUrls" in changes:
            call("/api/settings/forceUpdateBlockLists", token)
            log("block lists reloading")
        if not cur.get("enableBlocking", True) and (rep["blocked"] or rep["allowed"] or rep["exceptions"]):
            log("note: blocking is turned OFF in the web console (Settings > Blocking), so the lists have no effect")

        sync_override_zones(token, rep["overrides"])
    finally:
        try:
            call("/api/user/logout", token)
        except Exception:  # noqa: BLE001
            pass
    log("done")


if __name__ == "__main__":
    main()
