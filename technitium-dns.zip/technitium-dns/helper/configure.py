#!/usr/bin/env python3
"""Sync the few Technitium settings this stack owns, plus the custom lists from .env.

Only these are touched (everything else stays however you set it in the web console):
  - DNS-over-TCP-PROXY on 538 and DNS-over-HTTP on 80, inside the Docker network only
    (the TLS fronts forward to them; they are never published on the host)
  - the reverse-proxy ACL: real client IPs are trusted only from the TLS fronts' fixed IPs
  - the block list URLs pasted in DNS_BLOCKLIST_URLS, plus two entries for the
    custom rules (block list URLs you add in the web console yourself are kept)
  - local zones that make your custom block rules beat any allow (see lists.overrides)
  - the admin account's username (DNS_ADMIN_USERNAME)

"configure.py --watch" keeps running and re-checks the override zones whenever
Technitium re-downloads the lists, so your rules keep winning after list updates.
"""
import fcntl
import hashlib
import json
import os
import sys
import time
import urllib.parse
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import envfile  # noqa: E402
import lists  # noqa: E402

API = "http://dns:5380"
STACK_ENV = "/stack.env"
LIST_DIR = "/etc/dns/lists"
BLOCK_URL = "file:///etc/dns/lists/custom-blocklist.txt"
ALLOW_URL = "!file:///etc/dns/lists/custom-allowlist.txt"
OVERRIDE_STATE = "/etc/dns/lists/override-zones.json"
ADMIN_STATE = "/etc/dns/lists/admin-username"
URL_STATE = "/etc/dns/lists/managed-urls.json"
LOCK_FILE = "/etc/dns/lists/.sync.lock"
CACHE_DIR = "/etc/dns/blocklists"   # where Technitium keeps downloaded lists
HEARTBEAT = "/tmp/heartbeat"


def log(msg):
    print(time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()) + " [configure] " + msg, flush=True)


def call(path, token=None, method="GET", **params):
    if token:
        params["token"] = token
    data = None
    url = API + path
    if method == "POST":
        data = urllib.parse.urlencode(params).encode()
    elif params:
        url += "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, data=data, method=method)
    with urllib.request.urlopen(req, timeout=30) as r:
        body = json.load(r)
    if body.get("status") != "ok":
        raise RuntimeError(f"{path}: {body.get('status')}: {body.get('errorMessage', '')}")
    return body.get("response", {})


def wait_for_api(seconds=180):
    deadline = time.time() + seconds
    while True:
        try:
            with urllib.request.urlopen(API + "/", timeout=5):
                return
        except Exception as e:  # noqa: BLE001
            if time.time() > deadline:
                raise SystemExit(f"Technitium web API not reachable at {API}: {e}")
            time.sleep(2)


def write_if_changed(path, text):
    try:
        with open(path, encoding="utf-8") as f:
            if f.read() == text:
                return False
    except FileNotFoundError:
        pass
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
    os.replace(tmp, path)
    return True


def sync_override_zones(token, overrides):
    """Make block rules under an allowed parent actually block.

    Technitium lets any allow beat any block, so ||telemetry.gfe.nvidia.com would
    lose to @@||nvidia.com^. A local zone is answered before allow/block is even
    checked, so each such name gets an empty Primary zone: the name and all its
    subdomains get no address, while the rest of nvidia.com stays allowed.
    Only zones this stack created (tracked in OVERRIDE_STATE) are ever removed.
    """
    try:
        with open(OVERRIDE_STATE, encoding="utf-8") as f:
            managed = set(json.load(f))
    except (FileNotFoundError, ValueError):
        managed = set()
    existing = {z["name"].lower() for z in call("/api/zones/list", token).get("zones", [])}
    want = set(overrides)

    for zone in sorted(want):
        if zone in existing:
            if zone not in managed:
                log(f"  {zone}: you already have a zone with this name in the web console, leaving it as is")
            continue
        # new, or ours but deleted in the web console: (re)create it
        call("/api/zones/create", token, method="POST", zone=zone, type="Primary")
        managed.add(zone)
        log(f"  blocking {zone} (and its subdomains): {overrides[zone]}, your rule wins")
    for zone in sorted(managed - want):
        if zone in existing:
            call("/api/zones/delete", token, method="POST", zone=zone)
            log(f"  {zone}: no longer needed (rule removed, or nothing allows it any more), zone removed")
        managed.discard(zone)
    managed &= want

    write_if_changed(OVERRIDE_STATE, json.dumps(sorted(managed), indent=1) + "\n")
    if want:
        log(f"custom blocks enforced over allows: {len(want)} ({', '.join(sorted(want)[:10])}"
            f"{', ...' if len(want) > 10 else ''})")


def login(user, password):
    """Return a session token, or None if these credentials are wrong."""
    req = urllib.request.Request(
        API + "/api/user/login", method="POST",
        data=urllib.parse.urlencode({"user": user, "pass": password, "includeInfo": "false"}).encode())
    with urllib.request.urlopen(req, timeout=30) as r:
        body = json.load(r)
    return body["token"] if body.get("status") == "ok" else None


def admin_session(username, password):
    """Log in as DNS_ADMIN_USERNAME, renaming the account to it first if needed.

    Technitium always creates the first account as "admin" (it has no setting for
    the name), so on the first run it's renamed to DNS_ADMIN_USERNAME. If you
    change DNS_ADMIN_USERNAME later, the account is renamed again, found by the
    name this stack last gave it (ADMIN_STATE).
    """
    try:
        with open(ADMIN_STATE, encoding="utf-8") as f:
            previous = f.read().strip()
    except FileNotFoundError:
        previous = ""
    tried = []
    for name in dict.fromkeys([username, previous, "admin"]):
        if not name:
            continue
        tried.append(name)
        token = login(name, password)
        if token is None:
            continue
        if name.lower() != username.lower():
            call("/api/admin/users/set", token, method="POST", user=name, newUser=username)
            try:
                call("/api/user/logout", token)
            except Exception:  # noqa: BLE001
                pass
            log(f"admin account renamed from '{name}' to '{username}'")
            token = login(username, password)
            if token is None:
                raise SystemExit(f"Renamed the admin account to '{username}' but couldn't log in with it")
        os.makedirs(os.path.dirname(ADMIN_STATE), exist_ok=True)
        write_if_changed(ADMIN_STATE, username + "\n")
        return token
    raise SystemExit(
        f"Login to Technitium failed as {' / '.join(repr(t) for t in tried)}. If you changed the admin "
        "username or password in the web console, put the same ones in DNS_ADMIN_USERNAME and "
        "DNS_ADMIN_PASSWORD in .env, then: docker compose up -d")


def read_json(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, ValueError):
        return default


def list_file(url):
    """Where Technitium keeps its copy of a block list URL."""
    if url.startswith("!"):
        url = url[1:]
    if url.startswith("file://"):
        return urllib.parse.urlparse(url).path
    return os.path.join(CACHE_DIR, hashlib.sha256(url.encode()).hexdigest())


def list_allows(block_urls):
    """Everything the block lists themselves allow, from Technitium's downloaded
    copies: @@ rules in block lists, and every entry of a "!" allow list you
    added in the web console."""
    allowed = set()
    for u in block_urls:
        if u in (BLOCK_URL, ALLOW_URL):
            continue
        path = list_file(u)
        if u.startswith("!"):
            try:
                with open(path, encoding="utf-8", errors="replace") as f:
                    allowed.update(lists.build("", f.read())[2]["allow_domains"])
            except OSError:
                pass
        else:
            allowed |= lists.list_exceptions(path)
    return allowed


def lists_signature(block_urls):
    """Changes whenever Technitium re-downloads a list or the rules in .env change."""
    sig = []
    for u in block_urls:
        try:
            st = os.stat(list_file(u))
            sig.append((u, st.st_mtime_ns, st.st_size))
        except OSError:
            sig.append((u, 0, 0))
    try:
        sig.append(("env", os.stat(STACK_ENV).st_mtime_ns, 0))
    except OSError:
        pass
    return sig


def read_rules():
    """Your custom rules from .env (read from the file, so big pastes work)."""
    env = envfile.read(STACK_ENV)
    # One paste area with AdGuard rule meaning (|| blocks, @@ allows). The older
    # separate DNS_CUSTOM_BLOCKLIST / DNS_CUSTOM_ALLOWLIST keys still work if present.
    rules = "\n".join(env.get(k, "") for k in ("DNS_CUSTOM_RULES", "DNS_CUSTOM_BLOCKLIST"))
    return env, lists.build(rules, env.get("DNS_CUSTOM_ALLOWLIST", ""))


def enforce_custom_blocks(token, rep, block_urls):
    with open(LOCK_FILE, "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)   # configure and the watcher never edit zones at once
        ov = lists.overrides(rep["block_domains"], rep["allow_domains"], list_allows(block_urls))
        sync_override_zones(token, ov)


def credentials():
    username = os.environ.get("DNS_ADMIN_USERNAME", "").strip()
    password = os.environ.get("DNS_ADMIN_PASSWORD", "")
    if not username or username.lower() == "admin" or not password:
        raise SystemExit("DNS_ADMIN_USERNAME and DNS_ADMIN_PASSWORD must both be set in .env "
                         "(and the username can't be 'admin'), then: docker compose up -d")
    return username, password


def logout(token):
    try:
        call("/api/user/logout", token)
    except Exception:  # noqa: BLE001
        pass


def main():
    username, password = credentials()
    proxies = [ip for ip in (os.environ.get("TLS_BACKEND_IP", ""), os.environ.get("TLS_DIRECT_IP", "")) if ip]

    wait_for_api()
    token = admin_session(username, password)

    try:
        # ── custom rules ──
        env, (bl_text, al_text, rep) = read_rules()
        os.makedirs(LIST_DIR, exist_ok=True)
        lists_changed = write_if_changed(os.path.join(LIST_DIR, "custom-blocklist.txt"), bl_text)
        lists_changed |= write_if_changed(os.path.join(LIST_DIR, "custom-allowlist.txt"), al_text)
        log(f"custom rules: {rep['blocked']} blocked, {rep['exceptions'] + rep['allowed']} allowed"
            f"{' (changed)' if lists_changed else ' (unchanged)'}")
        for s in rep["skipped"][:50]:
            log("  skipped " + s)
        if len(rep["skipped"]) > 50:
            log(f"  ...and {len(rep['skipped']) - 50} more skipped")

        # ── block list URLs from .env ──
        env_urls = lists.parse_urls(env.get("DNS_BLOCKLIST_URLS", ""))
        managed_before = read_json(URL_STATE, [])

        # ── settings this stack owns ──
        cur = call("/api/settings/get", token)
        want = {
            "enableDnsOverTcpProxy": True, "dnsOverTcpProxyPort": 538,
            "enableDnsOverHttp": True, "dnsOverHttpPort": 80,
            "dnsOverHttpRealIpHeader": "X-Real-IP",
        }
        changes = {k: v for k, v in want.items() if cur.get(k) != v}

        acl = sorted(proxies)
        if sorted(cur.get("dnsReverseProxyNetworkACL") or []) != acl:
            changes["dnsReverseProxyNetworkACL"] = ",".join(acl)

        current = cur.get("blockListUrls") or []
        # keep URLs you added in the web console; drop ones this stack added that
        # are no longer in .env; then add everything from .env and the custom rules
        yours = [u for u in current if u not in (BLOCK_URL, ALLOW_URL) and u not in managed_before
                 and u not in env_urls]
        urls = yours + env_urls + [BLOCK_URL, ALLOW_URL]
        added = [u for u in env_urls if u not in current]
        removed = [u for u in managed_before if u in current and u not in env_urls]
        if current != urls:
            changes["blockListUrls"] = ",".join(urls)
        log(f"block lists: {len(env_urls)} from .env"
            f"{f', {len(added)} added' if added else ''}{f', {len(removed)} removed' if removed else ''}"
            f"{f', {len(yours)} added in the web console kept' if yours else ''}")

        if changes:
            post = {k: (str(v).lower() if isinstance(v, bool) else str(v)) for k, v in changes.items()}
            call("/api/settings/set", token, method="POST", **post)
            log("updated settings: " + ", ".join(sorted(changes)))
        else:
            log("settings already correct")
        write_if_changed(URL_STATE, json.dumps(env_urls, indent=1) + "\n")

        if lists_changed or "blockListUrls" in changes:
            call("/api/settings/forceUpdateBlockLists", token)
            log("block lists reloading (downloads continue in the background; the watcher "
                "re-checks your rules once they finish)")
        if not cur.get("enableBlocking", True):
            log("note: blocking is turned OFF in the web console (Settings > Blocking), so the lists have no effect")

        enforce_custom_blocks(token, rep, urls)
    finally:
        logout(token)
    log("done")


def watch():
    """Re-check the override zones whenever a list is re-downloaded or .env changes."""
    username, password = credentials()
    interval = max(30, int(os.environ.get("LIST_WATCH_SECONDS", "60") or 60))
    wait_for_api()
    log(f"watching block lists every {interval}s")
    last = None
    urls = (read_json(URL_STATE, []) or []) + [BLOCK_URL, ALLOW_URL]
    while True:
        try:
            open(HEARTBEAT, "w").close()
            if lists_signature(urls) != last:
                token = admin_session(username, password)
                try:
                    # Technitium's real list of URLs (includes ones you added in the console)
                    urls = call("/api/settings/get", token).get("blockListUrls") or urls
                    _, (_, _, rep) = read_rules()
                    enforce_custom_blocks(token, rep, urls)
                finally:
                    logout(token)
                last = lists_signature(urls)
        except SystemExit as e:
            log(f"ERROR: {e}")
        except Exception as e:  # noqa: BLE001
            log(f"check failed, retrying next round: {e}")
        time.sleep(interval)


if __name__ == "__main__":
    if "--watch" in sys.argv:
        watch()
    else:
        main()
