#!/usr/bin/env python3
"""Minimal .env reader that understands multi-line quoted values, like Docker Compose.

Used by configure.py (to read the pasted lists straight from .env, so a big list
never hits the kernel's 128 KiB limit on a single environment variable) and by
deploy-update.sh (to merge new keys without mangling the multi-line list blocks).
"""


def entries(text):
    """Yield (key, value, raw_block) in file order. Comments/blank lines are skipped."""
    lines = text.splitlines(keepends=True)
    i = 0
    while i < len(lines):
        line = lines[i]
        s = line.strip()
        if not s or s.startswith("#") or "=" not in s:
            i += 1
            continue
        key, rest = line.split("=", 1)
        key = key.strip()
        if key.startswith("export "):
            key = key[7:].strip()
        val = rest.rstrip("\r\n")
        raw = [line]
        q = val[:1]
        if q in ("'", '"') and not (len(val) > 1 and val.rstrip().endswith(q)):
            # opening quote with no closing quote on this line: multi-line value
            buf = [val[1:]]
            i += 1
            while i < len(lines):
                raw.append(lines[i])
                ln = lines[i].rstrip("\r\n")
                if ln.rstrip().endswith(q):
                    buf.append(ln.rstrip()[:-1])
                    break
                buf.append(ln)
                i += 1
            value = "\n".join(buf)
        elif q in ("'", '"'):
            value = val.rstrip()[1:-1]
        else:
            value = val.split(" #", 1)[0].strip()
        yield key, value, "".join(raw)
        i += 1


def read(path):
    with open(path, encoding="utf-8") as f:
        return {k: v for k, v, _ in entries(f.read())}
