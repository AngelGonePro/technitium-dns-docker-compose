#!/usr/bin/env python3
"""Turn AdGuard-style rules into files Technitium's block list reader understands.

Technitium reads ||domain^, @@||domain^, hosts lines and plain domains natively,
but an allow list ("!" URL) treats @@||domain^ as BLOCK (its "exception" flips),
and it ignores ||domain^$important. So both lists are rewritten to plain
||domain^ / @@||domain^ lines, and anything it can't express is reported.
"""
import ipaddress
import re

_LABEL = re.compile(r"^(?!-)[a-z0-9_-]{1,63}(?<!-)$")
# AdGuard modifiers that still mean "block/allow this whole domain for everyone".
_HARMLESS_MODIFIERS = {"important", "all", "doc", "document"}


def _valid_domain(d):
    if not d or len(d) > 253:
        return False
    try:
        ipaddress.ip_address(d)
        return False
    except ValueError:
        pass
    labels = d.split(".")
    return all(_LABEL.match(l) for l in labels)


def _parse_rule(line):
    """Return (kind, domain) with kind 'block'/'allow', None for comments, or ('skip', reason)."""
    s = line.strip()
    if not s or s.startswith(("!", "#")):
        return None
    if s.startswith("/") and s.endswith("/") and len(s) > 1:
        return ("skip", "regex rules aren't supported")

    kind = "block"
    if s.startswith("@@"):
        kind, s = "allow", s[2:]

    if s.startswith("||"):
        s = s[2:]
        mods = ""
        if "$" in s:
            s, mods = s.split("$", 1)
        # Trailing separators: ^, ^^ (a common typo AdGuard tolerates), ^|
        s = s.rstrip("^|")
        if mods:
            bad = [m for m in mods.split(",") if m.strip().lower() not in _HARMLESS_MODIFIERS]
            if bad:
                return ("skip", "modifier $" + ",".join(bad) + " isn't supported")
    elif s.startswith("|") or "/" in s:
        return ("skip", "URL rules aren't DNS rules")
    else:
        parts = s.split()
        if len(parts) >= 2:
            # hosts format: <ip> <name> [more names / # comment]
            try:
                ipaddress.ip_address(parts[0])
            except ValueError:
                return ("skip", "not a recognised rule")
            s = parts[1]
        elif len(parts) == 1:
            s = parts[0]
        if "$" in s:
            return ("skip", "modifiers on a plain domain aren't supported")

    s = s.strip().strip(".").lower()
    if s.startswith("*."):
        s = s[2:]  # *.example.com == example.com + subdomains here
    if s in ("localhost", "localhost.localdomain", "local", "broadcasthost"):
        return None
    if "*" in s:
        return ("skip", "wildcards inside a name aren't supported")
    if not _valid_domain(s):
        return ("skip", "not a valid domain name")
    return (kind, s)


def build(blocklist_text, allowlist_text):
    """Return (blocklist_file_text, allowlist_file_text, report dict)."""
    block, block_exc, allow, skipped = [], [], [], []
    seen = set()

    for src, text in (("blocklist", blocklist_text), ("allowlist", allowlist_text)):
        lines = (text or "").splitlines()
        # A paste of AdGuard custom filtering rules mixes @@ (allow) and || (block)
        # lines. If the allowlist box has any @@ lines, its bare || lines are block
        # rules from that paste, not allow entries, so they keep their meaning.
        mixed = src == "allowlist" and any(l.strip().startswith("@@") for l in lines)
        for n, raw in enumerate(lines, 1):
            r = _parse_rule(raw)
            if r is None:
                continue
            kind, val = r
            if kind == "skip":
                skipped.append(f"{'line' if src == 'blocklist' else 'allowlist line'} {n}: {raw.strip()}  ({val})")
                continue
            if src == "allowlist" and not (mixed and kind == "block" and raw.strip().startswith("||")):
                kind = "allow"  # everything else in the allowlist means allow
            dest = "allowlist" if (src == "allowlist" and kind == "allow") else "blocklist"
            key = (dest, kind, val)
            if key in seen:
                continue
            seen.add(key)
            if dest == "allowlist":
                allow.append(val)
            elif kind == "allow":
                block_exc.append(val)
            else:
                block.append(val)

    header = "! Generated from .env by technitium-dns configure. Edit .env, not this file.\n"
    bl = header + "".join(f"||{d}^\n" for d in block) + "".join(f"@@||{d}^\n" for d in block_exc)
    al = header + "".join(f"||{d}^\n" for d in allow)
    report = {"blocked": len(block), "exceptions": len(block_exc), "allowed": len(allow), "skipped": skipped,
              "block_domains": block, "allow_domains": block_exc + allow}
    return bl, al, report


def overrides(blocked, custom_allowed, list_allowed=()):
    """Custom block rules that an allow would otherwise beat (Technitium lets any
    allow win over any block). configure.py gives each one a local zone, which is
    answered before allow/block is checked, so your block wins.

    - against your own allows: a block under an allowed parent
      (||telemetry.gfe.nvidia.com with @@||nvidia.com^). The very same name both
      blocked and allowed stays allowed, as in AdGuard.
    - against allows inside downloaded lists (their @@ rules): your block always
      wins, whether the list allows that name, a parent, or a subdomain of it.

    Returns {blocked_domain: reason}, keeping only the top-most name of a nested
    group (its zone covers everything below it)."""
    custom_allowed = set(custom_allowed)
    list_allowed = set(list_allowed)
    # every parent of every list allow, so "list allows a subdomain of D" is a lookup
    list_parents = set()
    for a in list_allowed:
        labels = a.split(".")
        for i in range(len(labels) - 1):
            list_parents.add(".".join(labels[i:]))
    found = {}
    for d in set(blocked):
        if d in custom_allowed:
            continue  # you allowed this exact name yourself
        labels = d.split(".")
        parents = [".".join(labels[i:]) for i in range(1, len(labels) - 1)]
        own = next((p for p in parents if p in custom_allowed), None)
        if own:
            found[d] = f"{own} is allowed in your rules"
        elif d in list_parents or any(p in list_allowed for p in parents):
            hit = d if d in list_allowed else next((p for p in parents if p in list_allowed), None)
            found[d] = f"a block list allows {hit}" if hit else "a block list allows part of it"
    return {d: r for d, r in found.items()
            if not any(d.endswith("." + other) for other in found if other != d)}


def list_exceptions(path):
    """Domains a downloaded list allows (its @@||x^ rules), read exactly the way
    Technitium reads them. Streams the file, so big lists use little memory."""
    out = set()
    try:
        f = open(path, encoding="utf-8", errors="replace")
    except OSError:
        return out
    with f:
        for line in f:
            line = line.lstrip(" \t")
            if not line.startswith("@@||"):
                continue
            line = line.rstrip("\r\n")
            i = line.find("^")
            if i > -1:
                d, opts = line[4:i], line[i + 1:]
                if opts and not (opts.startswith("$") and ("doc" in opts or "all" in opts)):
                    continue
            else:
                d = line[4:]
            d = d.lower()
            if _valid_domain(d):
                out.add(d)
    return out


_URL = re.compile(r"https?://[^\s<>\"']+")


def parse_urls(text):
    """Block list URLs from anything pasted: one per line, or AdGuard Home's
    blocklist page copied as-is (names, counts and dates are ignored)."""
    seen = []
    for u in _URL.findall(text or ""):
        u = u.rstrip(".,;)")
        if u not in seen:
            seen.append(u)
    return seen
